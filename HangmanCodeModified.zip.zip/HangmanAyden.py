import pygame
import math
import random

# Setup display
pygame.init()
WIDTH, HEIGHT = 1200, 800
win = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Hangman Game!")

# Button variables
RADIUS = 20
GAP = 15
letters = []
start_x = round((WIDTH - (RADIUS * 2 + GAP) * 13) / 2)
start_y = 400
A = 65
for i in range(26):
    x = start_x + GAP * 2 + ((RADIUS * 2 + GAP) * (i % 13))
    y = start_y + ((i // 13) * (GAP + RADIUS * 2))
    letters.append([x, y, chr(A + i), True])

# Fonts
LETTER_FONT = pygame.font.SysFont('comicsans', 40)
WORD_FONT = pygame.font.SysFont('comicsans', 60)
TITLE_FONT = pygame.font.SysFont('comicsans', 70)

# Load images
images = [pygame.image.load(f"hangman{i}.png") for i in range(7)]

# Game variables
hangman_status = 0
words_with_hints = {
    "IDE": "Tool for coding",
    "REPLIT": "Online coding platform",
    "PYTHON": "Popular programming language",
    "PYGAME": "Library for making games",
    "ALGORITHM": "Step-by-step problem-solving approach",
    "VARIABLE": "Stores a value in programming",
    "FUNCTION": "Reusable block of code",
    "DEBUGGING": "Finding and fixing errors",
    "LOOP": "Repeats a block of code",
    "SYNTAX": "Rules of a programming language"
}
word, hint = random.choice(list(words_with_hints.items()))
guessed = []

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)


def draw():
    """Draws the game window."""
    win.fill(WHITE)
    
    # Draw title
    text = TITLE_FONT.render("DEVELOPER HANGMAN", True, BLACK)
    win.blit(text, (WIDTH / 2 - text.get_width() / 2, 20))
    
    # Draw hint
    hint_text = WORD_FONT.render(f"Hint: {hint}", True, BLACK)
    win.blit(hint_text, (WIDTH / 2 - hint_text.get_width() / 2, 100))
    
    # Draw word
    display_word = " ".join([letter if letter in guessed else "_" for letter in word])
    text = WORD_FONT.render(display_word, True, BLACK)
    win.blit(text, (WIDTH / 2 - text.get_width() / 2, 200))
    
    # Draw buttons
    for letter in letters:
        x, y, ltr, visible = letter
        if visible:
            pygame.draw.circle(win, BLACK, (x, y), RADIUS, 3)
            text = LETTER_FONT.render(ltr, True, BLACK)
            win.blit(text, (x - text.get_width() / 2, y - text.get_height() / 2))
    
    win.blit(images[hangman_status], (150, 100))
    pygame.display.update()


def display_message(message):
    """Displays a message at the end of the game."""
    pygame.time.delay(1000)
    win.fill(WHITE)
    text = WORD_FONT.render(message, True, BLACK)
    win.blit(text, (WIDTH / 2 - text.get_width() / 2, HEIGHT / 2 - text.get_height() / 2))
    pygame.display.update()
    pygame.time.delay(2000)


def reset_game():
    """Resets the game variables for a new round."""
    global hangman_status, word, hint, guessed, letters
    hangman_status = 0
    word, hint = random.choice(list(words_with_hints.items()))
    guessed = []
    for letter in letters:
        letter[3] = True


def main():
    """Main game loop."""
    global hangman_status
    
    FPS = 60
    clock = pygame.time.Clock()
    run = True
    
    while run:
        clock.tick(FPS)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                m_x, m_y = pygame.mouse.get_pos()
                for letter in letters:
                    x, y, ltr, visible = letter
                    if visible:
                        dis = math.sqrt((x - m_x) ** 2 + (y - m_y) ** 2)
                        if dis < RADIUS:
                            letter[3] = False
                            guessed.append(ltr)
                            if ltr not in word:
                                hangman_status += 1
        
        draw()
        
        # Check for win condition
        if all(letter in guessed for letter in word):
            display_message("You WON!")
            return
        
        # Check for loss condition
        if hangman_status == 6:
            display_message(f"You LOST! The word was {word}")
            return


def game_loop():
    """Handles the game loop with retry/quit options."""
    while True:
        main()
        
        # Ask user to retry or quit
        win.fill(WHITE)
        text = WORD_FONT.render("Play Again? (Y/N)", True, BLACK)
        win.blit(text, (WIDTH / 2 - text.get_width() / 2, HEIGHT / 2))
        pygame.display.update()
        
        waiting = True
        while waiting:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_y:
                        reset_game()
                        waiting = False
                    elif event.key == pygame.K_n:
                        pygame.quit()
                        return


game_loop()
